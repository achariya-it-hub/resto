const mongoose = require('mongoose');

const hotelManagerSchema = new mongoose.Schema({
  name: String,
  code: { type: String, unique: true },
  referrals: { type: Number, default: 0 },
  earnings: { type: Number, default: 0 }
});

module.exports = mongoose.model('HotelManager', hotelManagerSchema);