const express = require('express');
const cors = require('cors');
const mongoose = require('mongoose');
require('dotenv').config();

const app = express();
app.use(cors());
app.use(express.json());

const PORT = process.env.PORT || 5000;
const mongoURI = process.env.MONGO_URI;

mongoose.connect(mongoURI, {
  useNewUrlParser: true,
  useUnifiedTopology: true
})
.then(() => console.log('✅ MongoDB connected'))
.catch(err => console.log('❌ DB error:', err));

const HotelManager = require('./models/HotelManager');

app.get('/api/managers', async (req, res) => {
  const managers = await HotelManager.find();
  res.json(managers);
});

app.post('/api/referral', async (req, res) => {
  const { code } = req.body;
  const manager = await HotelManager.findOne({ code });
  if (manager) {
    manager.referrals += 1;
    manager.earnings += 5;
    await manager.save();
    return res.json({ success: true, message: 'Referral logged.' });
  }
  res.status(404).json({ success: false, message: 'Invalid code.' });
});

// One-time seeding route (optional)
app.post('/api/seed', async (req, res) => {
  const managers = [
    { name: 'Hotel One', code: 'HOTEL123' },
    { name: 'Hotel Two', code: 'HOTEL456' },
  ];
  await HotelManager.insertMany(managers);
  res.send('Seeded');
});

app.listen(PORT, () => {
  console.log(`Server running on http://localhost:${PORT}`);
});