import React, { useState, useEffect } from 'react';
import axios from 'axios';

function App() {
  const [managers, setManagers] = useState([]);
  const [referralCode, setReferralCode] = useState('');
  const [message, setMessage] = useState('');

  useEffect(() => {
    axios.get('http://localhost:5000/api/managers')
      .then(res => setManagers(res.data));
  }, []);

  const submitReferral = () => {
    axios.post('http://localhost:5000/api/referral', { code: referralCode })
      .then(res => setMessage(res.data.message))
      .catch(err => setMessage(err.response.data.message));
  };

  return (
    <div className="p-6 max-w-2xl mx-auto">
      <h1 className="text-2xl font-bold mb-4">Restaurant Affiliate System</h1>
      <div className="mb-6">
        <h2 className="text-xl font-semibold mb-2">Log Referral</h2>
        <input className="border p-2 mr-2" placeholder="Enter Referral Code" value={referralCode} onChange={e => setReferralCode(e.target.value)} />
        <button className="bg-blue-600 text-white px-4 py-2 rounded" onClick={submitReferral}>Submit</button>
        {message && <p className="mt-2 text-green-600">{message}</p>}
      </div>
      <div>
        <h2 className="text-xl font-semibold mb-2">Hotel Manager Stats</h2>
        <table className="w-full text-left border">
          <thead>
            <tr>
              <th className="border px-2 py-1">Name</th>
              <th className="border px-2 py-1">Referrals</th>
              <th className="border px-2 py-1">Earnings ($)</th>
            </tr>
          </thead>
          <tbody>
            {managers.map(m => (
              <tr key={m.id}>
                <td className="border px-2 py-1">{m.name}</td>
                <td className="border px-2 py-1">{m.referrals}</td>
                <td className="border px-2 py-1">{m.earnings}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

export default App;